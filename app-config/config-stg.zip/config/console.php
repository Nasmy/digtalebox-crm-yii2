<?php
spl_autoload_unregister(array('YiiBase','autoload'));
require dirname(__FILE__) . '/../vendor/gplus/GooglePlusApi.php';
spl_autoload_register(array('YiiBase','autoload'));
// This is the configuration for yiic console application.
// Any writable CConsoleApplication properties can be configured here.
return CMap::mergeArray(
        array (
                'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'..',
                'name'=>'My Console Application',

                // preloading 'log' component
                'preload'=>array('log'),

                // autoloading model and component classes
                'import'=>array(
                        'application.models.*',
                        'application.components.*',
                        'application.vendor.twitterApi.*',
                        'application.vendor.le_php-master.*',
                        'application.vendor.PHPMailer.*',
                        'application.vendor.MailJet.*',
                        'application.vendor.LinkedIn.*',
                        'application.vendor.yii-facebook-opengraph.*',
                        'application.vendor.mailchimpApi.*',
                        'application.vendor.bitly.*',
                ),
                'commandMap' => array(
                        'migrate' => array(
                                'class' => 'application.commands.MigrateCommand',
                                'migrationPath' => 'application.migrations',
                                'migrationTable' => 'Migration',
								'connectionID' => 'db',
                                'templateFile' => 'application.migrations.MigrateTemplate',
                        ),
                ),
                // application components
                'components'=>array(
                        'log'=>array(
                                'class'=>'CLogRouter',
                                'routes'=>array(
                                        array(
                                                'class'=>'CFileLogRoute',
                                                'levels'=>'error, warning',
                                        ),
                                ),
                        ),
                        'toolKit' => array(
                                'class' => 'ToolKit',
                        ),
                ),
                'params'=>array(
                        'isConsole'=>true,
                        'backup'=>array(
                                'database' => true,
                                'dbPath' => '/tmp/digitalebox/mysql/',
                                'directory' => array(
                                        'mysql/' => '/tmp/digitalebox/mysql/',
                                        'resources/' => '/var/www/digital_box_v1/resources/'
                                ),
                                'remoteCopy' => true,
                                'localCopy' => false,
                                'ftp' => array(
                                        'host'=>'localhost',
										'username' => 'ftpuser',
                                        'password' => 'ftpuser123',
                                        'path' => './files/',
                                ),
                                'dir' => array(
                                        'path' => '/tmp/digitalebox/local/',
                                ),
                                'name' => 'digitalebox_app_' . date('Y-m-d_H') . '.zip',
                                'path' => '/tmp/digitalebox/zip/',
                                'excludeDirectory' => array(
                                        //<Absolute path to directory>
                                ),
                                'excludeFile' => array(
                                        //<Absolute path to file>
                                ),
                        ),
                        'moveDeleteBackup'=>array(
                                'sourcePath' => '/home/dbox/digitalebox/',
                                'destinationPath' => '/srv/datadisk01/liveBackups/',
                                'noOfDays' => 3, // how many days old files to clean
                                'logSourcePath' => '/var/log/digitalebox/',
                                'logDestinationPath' => '/srv/datadisk01/liveBackups/logs/',
                        ),
                ),
        ),
        local_config()
);

// return an array of custom local configuration settings
function local_config()
{
  if (file_exists(dirname(__FILE__).'/config.php'))
  {
    return require_once(dirname(__FILE__).'/config.php');
  }

  return array();
};
