<?php

require dirname(__FILE__) . '/../vendor/stripe/lib/Stripe.php';

// Application log base path
define('LOG_BASE_PATH', '/var/log/');
define('SYS_TMP_PATH', '/tmp/');
define('BULK_INSERT_PATH', '/var/www/html/DigitaleBoxUIRevamp/Upload');  
return array(
        'components'=>array(
                // This connection initially connected with master database and
                // dynamically change according to database
                'db'=>array(
                        'connectionString' => 'mysql:host=54.37.148.213;dbname=DigitaleBoxMaster',
                        'emulatePrepare' => true,
                        'username' => 'stageuser',
                        'password' => '$taG3u$E666',
                        'charset' => 'utf8',
                        'enableParamLogging'=>true,
                        'enableProfiling'=>false,
                        'schemaCachingDuration'=>604800,
                ),


                // Always connected to master database
                'dbMaster'=>array(
                        'connectionString' => 'mysql:host=54.37.148.213;dbname=DigitaleBoxMaster',
                        'emulatePrepare' => true,
                        'username' => 'stageuser',
                        'password' => '$taG3u$E666',
			'charset' => 'utf8',
                        'enableParamLogging'=>true,
                        'enableProfiling'=>false,
                        'schemaCachingDuration'=>604800,
                        'class' => 'CDbConnection'
                ),

                'toolKit' => array (
                        'class' => 'ToolKit',
                ),

                'fa' => array (
                        'class' => 'Fa',
                ),

                'facebook'=>array(
                        // Jonny Junior - DBox
                'class' => 'application.vendor.yii-facebook-opengraph.FacebookApi',
                'appId'=>'2849661541716660',
                'secret'=>'d43010d849791e647de9c7bfead27a36',
                'limit' => 5000,
                ),

                'appLog' => array(
                        'class' => 'AppLogger',
                        'logType' => 1,
                        'logParams' => array(
                                1 => array(
                                        'logPath' => LOG_BASE_PATH . 'digitalebox/',
                                        'logName' => date('Ymd') . '-activity.log',
                                        'logLevel' => 3, // Take necessary value from apploger class
                                        'logSocket' => '172.16.13.6:3021',
                                ),
								2 => array(
                                        'logPath' => LOG_BASE_PATH . 'digitalebox/',
                                        'logName' => date('Ymd') . '-daemon.log',
                                        'logLevel' => 3, // Take necessary value from apploger class
                                        'logSocket' => '172.16.13.6:3021',
                                ),
                                3 => array(
                                        'logPath' => LOG_BASE_PATH . 'digitalebox/',
                                        'logName' => date('Ymd') . '-paypal.log',
                                        'logLevel' => 3, // Take necessary value from apploger class
                                        'logSocket' => '',
                                ),
                        ),
                ),
        ),

        // application-level parameters that can be accessed
        // using Yii::app()->params['paramName']
        'params'=>array(
                'copyRight' => Yii::t('messages', 'Copyright &copy; {date} by DigitaleBox. All Rights Reserved.', array('{date}'=>date('Y'))),

                // Console script path
                'consolePath' => '/var/www/html/DigitaleBoxUIRevamp/',

                // Absolute URL for application. Used in console apps to create dynamic URLs
                'absUrl' => "https://{domain}/index.php",

                // Absolute path to temp directory within web root
                'webTempAbsPath' => 'temp/',

                // Relative path to temp directory within web root
                'webTempRelPath' => 'temp/',
				 // Maximum upload size of candidate photo
                'maxImgSize' => 2,

                // Client profile thumbnail name
                'clientProfThumbName' => 'clientProfThumb',

                // Default page size
                'pageSize' => 10,

                // Paypal sandbox mode (true/false)
                'paypalSandbox' => true,

                // OSM params
                'openStreetMap' => array(
                  // 'consumerKey' => 'B6Q65MZaGmM2VUMo1GqNibyJXCTuEKiZ',
                  // 'consumerSecret' => 'v40u3Bg9eiMu9qiN'
                  'consumerKey' => 'AAGaS7q0kui8K7UazMVSOfQRBlVoLUuh',
                  'consumerSecret' => 'DvZgFaWvZ6vqBfzp'
                ),

                // Twitter params
                'twitter' => array (
                        'consumerKey' => 'IHSaisHNQ3lpFBl8WYcpk68uR',
                        'consumerSecret' => '7AM4kBmHKRALNrFr0yJlRJwkViiq7z2E46FMlAL9b2hY4BhDpi',
                        'callbackUrl' => "https://staging.moncenis.com/index.php/Signup/Callback/network/%s/?domain=%s",
			'redirectUri' => "https://%s/index.php/Signup/Callback/network/%s/?oauth_token=%s&&oauth_verifier=%s",
                        'oauthToken' => '2427209282-TEsz34fqR04Iz1Qwv6qGvsxBdFtVwRIUqduytqe',
                        'oauthTokenSecret' => ' HS7VoPL9iFz5OPIpgAyTsVW3sTmukctDoETMqC6LvaWJn',
                        'maxFollowBack' => '20',        // Maximum number of daily Twitter followback
                        'maxFollowOther' => '20',       // Maximum number of daily following of other account
                        'maxUnfollow' => '20',          // Maximum number of daily unfollowings
                        'unfolDays' => '4'                      // Number of day to keep following before unfollow 
                ),

                // Facebook parameters
                'facebook' => array(
                        'loginScope' => array(
                                // 'public_profile',
                                'email',
                                // 'user_friends',
                                // Need approval
				// 'user_location',
                                // 'manage_pages',
                                // 'publish_pages',
                                // 'publish_actions',
                        ),
                        'redirectUri' => "https://%s/index.php/Signup/Callback/network/%s",
                ),

                'linkedIn' => array(
                        'apiKey' => '75bc939zjxuptj',
                        'apiSecret' => 'a9xJufTlNQ4mIpLz',
                        'callbackUrl' => 'https://staging.moncenis.com/index.php/authCallBack/LinkedInCallback',
                        'maxPagePostBackDays'=>10, // Maximum number of days to fetch Linked page posts from current date
                        'tokenRefreshDays' => 50
                ),

                // Google API https://code.google.com/apis/console/?noredirect&pli=1#project:618443992883:access
                'google' => array(
                        // Project APIs
                        'apiKey'=>'AIzaSyCUDSJ2GBE1DHupbAZT4u8gZqclkIhmb0M',

                        // Project Digitalebox-Staging
                        'clientId'=>'47312430286-of3dodvbj45q592gv4ihdcs7h1ffb90r.apps.googleusercontent.com',
                        'clientSecret'=>'g64ZJyKaSd-e4baueVdtp_hm',
                        'redirectUri'=>'https://staging.moncenis.com/index.php/authCallBack/GoogleCallback',

                        // Request URIs
                        'uriGetContacts'=>'https://www.google.com/m8/feeds/contacts/{contact}/full?v=3.0',
                ),

                'googlePlus' => array (
                        'apiKey' => '47312430286-eott95qfv12tfaf9vu07nsk2e4m852qh.apps.googleusercontent.com',
						 'apiSecret' => 'taEAC0FBj4mFfUAeC_PyaSpc',
                        'redirectUri'=>'https://staging.moncenis.com/index.php/authCallBack/GooglePlusCallback',
                ),

                // Yahoo API https://developer.apps.yahoo.com/projects/tVDvRc5a
                'yahoo' => array(
                        'consumerKey' => 'dj0yJmk9N0FMZmw4VlMyTUZpJmQ9WVdrOWNGVndSemM0TldjbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1hMA--',
                        'consumerSecret' => '41773bea72562b04ed2f65052eb16cd0260bfc68',
                        'callbackUrl' => 'https://staging.digitalebox.fr/index.php/authCallBack/YahooCallback',
                        'oauthInitUrl' => 'https://peem.digitalebox.com/index.php/authCallBack/YahooOathInit',
                ),

                'instagram' => array(
                        'clientId' => 'a5c392bd02074e80b8743743b7400f69',
                        'clientSecret' => 'ad10f9514ae74ae2a84d974d474cda08',
                        'callbackUrl' => 'https://peeem.digitalebox.fr/index.php/AuthCallBack/InstagramCallBack'
                ),

                'mailchimp' => array(
                        'clientId' => '968420432554',
                        'clientSecret' => 'f49dc0ad0ac03c5116122d0f4a2dfbd2',
                        'callbackUri' => 'https://auth.moncenis.com/index.php/authCallBack/MailchimpCallBack',
                ),

                // SMTP connection settings
                'smtp' => array (
                        // Mailjet account
                        'host' => 'in.mailjet.com:25',
                        'username' => 'f627ce013979fe3cba606bce67d7a7bf',
                        'password' => '5c707c8d8760aaadb9f9de25a3cc9486',
                        'senderEmail' => 'system@digitalebox.fr', // For all the emails this will send as sender parameter
                        'defaultClientEmail' => 'contact@digitalebox.fr',
						  'senderLabel' => 'Digitalebox',
                        'eventCallbackUrl' => 'https://staging.moncenis/index.php/EmailApi/EmailEventCallback',
			'logsEmail' => 'log@digitalebox.fr',
                ),

                // SMS API
                'smsApi' => array (
                        'sid' => 'AC34f13cac8770da156f67466c5dfc2815',
                        'token' => '1f1ec973897a1b9507e1b23fd01a7646',
                        'defSenderId' => '+33644606440', //A Twilio phone number you purchased at twilio.com/console
                        'messagingServiceSid' => 'MG50fa7e0b84e37bccd22cbd09a1a68c64',
                ),

                'blyApi' => array (
                        'clientId' => 'bf9cb4f1ff238bdfc291fc99066f407e45ae15ce',
                        'clientSecret' => '63be365a9910221ffe023cf6d915a9664cfee5a0',
                        'callbackUrl' => 'https://staging.moncenis.com/index.php/authCallBack/BitlyCallback',
                        'genericAccessToken' => 'fa83be03c0a23e36e27c462f6552c2f0c0673296'
                ),

                'changeApi' => array(
                        'apiKey' => '32cf9810f982f95613cec5cce3154dc83966f2a89111661e6355938ad70b20f6',
                        'secret' => '6acc5384782f8449e2775c3abf7688ec89cfa1ac76c710f2a745ad5c323e5bc9',
                        'pageSize'=> 100,
                        'host'=> 'https://api.change.org',
                ),


                'fileUplaod' => array(
                        'people' => array(
                                'path'=> BULK_INSERT_PATH . '/',
                                'name'=> "%s_bulk_people" . date('_Y-m-d_') . "%s",
                                'delimiter' => ',',
                        ),
						 'status' => array(
                                'path' => BULK_INSERT_PATH . '/',
                                'name' => 'bulk_status_' . date('Y-m-d-H-i-s') . '.csv',
                                'address' => 'address_status_' . date('Y-m-d-H-i-s') . '.csv',
                        ),
						'error' => array(
                                'path' => BULK_INSERT_PATH . '/',
                                'name' => 'bulk_status_' . date('Y-m-d-H-i-s') . '.csv',
                            ),
                ),

                // Languages for localization
		'lang' => array(
			'en' => array(
				'identifier' => 'en',
				'flagName' => 'en.png',
				'name' => 'English',
			),
			'fr' => array(
				'identifier' => 'fr',
				'flagName' => 'fr.png',
				'name' => 'Français',
			),
			'pt' => array(
				'identifier' => 'pt',
				'flagName' => 'pt.png',
				'name' => 'Português',
			),
            		'it' => array(
                		'identifier' => 'it',
                		'flagName' => 'it.png',
                		'name' => 'Italiano',
           		 ),
            		'ru' => array(
                		'identifier' => 'ru',
                		'flagName' => 'ru.png',
                		'name' => 'Russian',
            		),
		),

                'stripe' => array (
                        'secretKey' => 'sk_test_9uQec8BCZUTFM2UlznJuhnJV',
                        'publishableKey' => 'pk_test_tedeA4LaVEEImn0vzC9DsAHM',
                        'currencyCode' => 'EUR',
			'cardBrands' => 'card-brands.png',
                ),

                // Currency types to configure on system
                'currencyTypes' => array(
                        'USD' => array('name' => 'U.S. Dollar', 'symbol'=> 'US$'),
                        'EUR' => array('name' => 'Euro', 'symbol'=> '�'),
                        'CAD' => array('name' => 'Canadian Dollar', 'symbol'=> 'C$'),
                ),

                // Domain of main application
                //'masterDomain' => '54.38.90.224',
                  'masterDomain' => '54.37.148.213',

                // Absolute path to resource folder
                'resourcePath'=>'/var/www/html/DigitaleBoxUIRevamp/resources/',

                // Ipinfo is a service to obtain geo details by IP. It allows 1000 free API requests per day
                // https://ipinfo.io
                'ipInfoUrl' => 'https://ipinfo.io/',

                // Default longitude and latitude to point map when long lat not available
                'defLongLat' => '45.227309, 14.868457', // Bellow Slovenia

                // Number of days to keep Email Events on EmailEventTracker table of Master database
				                'emailEventsDelExpire' => 10,

                // For these actions system check for user`s package limitations
                'thresholdActions' => array(
                        'People.Create',
                        'People.BulkInsert'
                ),

                // French special characters to be detected on SMS message
                'smsSpecialChars' => '�����',

                // Main application login URL
                'salesAppUrl' => 'https://moncenis.com/index.php/',

                'themes' => array(
                    1 => array(
                        'cssFile' => 'style-sky-blue.css',
                        'thumbnail' => 'skyblue-th.jpg',
                        'lgImage' => 'skyBlue.png',
                        'color' => '#2FA4E7',
                        'class' => 'theme-blue',
                        'preview' => 'theme-blue-preview.jpg',
                        'configTheme' => 'blue',
                        'themeName' => 'Blue'
                    ),
                    2 => array(
                        'cssFile' => 'style-green-tea.css',
                        'thumbnail' => 'green-tea-th.jpg',
                        'lgImage' => 'greenTea.png',
                        'color' => '#95AB63',
                        'class' => 'theme-green',
                        'preview' => 'theme-green-preview.jpg',
                        'configTheme' => 'green',
                        'themeName' => 'Green'
                    ),
                    3 => array(
                        'cssFile' => 'style-sunset.css',
                        'thumbnail' => 'sunset-th.jpg',
                        'lgImage' => 'sunset.png',
                        'color' => '#C33A1A',
                        'class' => 'theme-red',
                        'preview' => 'theme-red-preview.jpg',
                        'configTheme' => 'red',
                        'themeName' => 'Red'
                    ),
                    4 => array(
                        'cssFile' => 'style-indego.css',
                        'thumbnail' => 'indego-th.jpg',
                        'lgImage' => 'indego.png',
                        'color' => '#734061',
                        'class' => 'theme-purple',
                        'preview' => 'theme-purple-preview.jpg',
                        'configTheme' => 'purple',
                        'themeName' => 'Purple'
                    )
                ),

            'emailDomain' => array(
                'url1' => 'https://template.digitalebox.fr',
                'url2' => 'https://template.moncenis.com'
            ),

            'privacyPolicy' => 'https://sales.moncenis.com/index.php/site/privacy',
            'privacyUrl' => 'https://moncenis.com/index.php/site/privacy',

            'tawkId' => '5aa6573fd7591465c7087a15',

            'campaign' => array(
                'campaignEmail' => 'campaign@digitalebox.fr',
                'limit' => 5,
            ),
        ),
);
?>
