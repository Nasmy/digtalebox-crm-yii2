<?php

$params = require __DIR__ . '/params.php';
$db = require __DIR__ . '/db.php';
// define('LOG_BASE_PATH', '/var/log/');

$config = [
    'id' => 'basic-console',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'controllerNamespace' => 'app\commands',
    'aliases' => [
        '@bower' => '@vendor/bower-asset',
        '@npm' => '@vendor/npm-asset',
        '@tests' => '@app/tests',
    ],
    'components' => [
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'i18n' => [
            'translations' => [
                'mail' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/messages'
                ],
                'messages' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/messages'
                ],
                'activityMessages' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/messages',
                    'sourceLanguage' => 'en-US'
                ],

                'alpha' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/messages'
                ],
                'faq' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/messages'
                ],
            ],
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'flushInterval' => 1,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning', 'info'],
                    'categories' => ['activity_log'],
                    'exportInterval' => 1,
                    'logFile' => EXTERNAL_LOG_PATH . 'logs/activity.log.' . date('Ymd') . '.log', // important
                    'maxFileSize' => 1024 * 2,
                    'maxLogFiles' => 20,
                ],
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning', 'info'],
                    'categories' => ['daemon_log'],
                    'exportInterval' => 1,
                    'logFile' => EXTERNAL_LOG_PATH . 'logs/daemon.log.' . date('Ymd') . '.log', // important
                    'maxFileSize' => 1024 * 2,
                    'maxLogFiles' => 20,
                ],
            ],
        ],
        'appLog' => [
            'class' => 'app\components\AppLogger',
            'logType' => 1,
            'logParams' => [
                1 => [
                    'logPath' => LOG_BASE_PATH . 'digitalebox/',
                    'logName' => '-activity.log',
                    'logLevel' => 3, // Take necessary value from apploger class
                    'logSocket' => '',
                    'isConsole' => false
                ],
                2 => [
                    'logPath' => LOG_BASE_PATH . 'digitalebox/',
                    'logName' => '-daemon.log',
                    'logLevel' => 3, // Take necessary value from apploger class
                    'logSocket' => '',
                    'isConsole' => false
                ]
            ]
        ],

        // SMS API
        'sms' => [
            'class' => 'wadeshuler\sms\twilio\Sms',

            // Advanced app use '@common/sms', basic use '@app/sms'
            'viewPath' => '@app/sms',     // Optional: defaults to '@app/sms'

            // send all sms to a file by default. You have to set
            // 'useFileTransport' to false and configure the messageConfig['from'],
            // 'sid', and 'token' to send real messages
            'useFileTransport' => false,

            'messageConfig' => [
                'from' => '+33644606440',  // Your Twilio number (full or shortcode)
            ],

            // Find your Account Sid and Auth Token at https://twilio.com/console
            'sid' => 'AC34f13cac8770da156f67466c5dfc2815',
            'token' => '1f1ec973897a1b9507e1b23fd01a7646',

            // Tell Twilio where to POST information about your message.
            // @see https://www.twilio.com/docs/sms/send-messages#monitor-the-status-of-your-message
            //'statusCallback' => 'https://example.com/path/to/callback',      // optional
            'statusCallback' => 'https://vpv.digitalebox.com/index.php/sms-api/sms-event-callback',     // optional
        ],

        'toolKit' => [
            'class' => 'app\components\ToolKit',
        ],
        'db' => $db,

        'dbMaster' => [
            'class' => 'yii\db\Connection',
            'emulatePrepare' => true,
            'dsn' => 'mysql:host=51.38.45.224;dbname=DigitaleBoxMaster',
            'username' => 'stageuser',
            'password' => 'Jskdi$q9G19UYt',
            'charset' => 'utf8',
        ],

        'thresHoldChecker' => [
            'class' => 'app\components\ThresholdChecker',
        ],


        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
                '<controller:\w+>/<id:\d+>' => '<controller>/view',
                '<controller:\w+>/<action:\w+>/<id:\d+>' => '<controller>/<action>',
                '<controller:\w+>/<action:\w+>' => '<controller>/<action>',
                '<controller:[a-z-]+>/<action:[a-z-]+>/<id:\d+>/<param:[a-z-]+>'=> '<controller>/<action>',
                '<controller:[a-z-]+>/<action:[a-z-]+>/<param:[a-z-]+>/<id:\d+>'=> '<controller>/<action>',
                'advanced-search/stop-bulk-export/<id:\d+>' => 'advanced-search/stop-bulk-export',
                'advanced-search/stop-bulk-edit/<id:\d+>' => 'advanced-search/stop-bulk-edit',
                'advanced-search/stop-bulk-delete/<id:\d+>' => 'advanced-search/stop-bulk-delete',
            ],
        ],

    ],
    'params' => $params,

];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
    ];
}

return $config;
