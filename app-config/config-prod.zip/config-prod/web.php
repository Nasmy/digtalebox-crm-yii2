<?php

$params = require __DIR__ . '/params.php';
$db = require __DIR__ . '/db.php';
define('VENDOR_PATH', '/var/www/html/DigitaleBoxMigration/protected/vendor/');


$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log', [
        'class' => 'app\components\LanguageSelector',
        'supportedLanguages' => ['en-US', 'fr-FR'],]
    ],
    // 'language'=>'en-US',
    // 'sourceLanguage'=>'fr-FR',
    'aliases' => [
        '@bower' => '@vendor/bower-asset',
        '@npm' => '@vendor/npm-asset',
        '@ext' => '@app/extensions/intlphoneinput',
        '@extensions' => '@app/extensions',
    ],

    'extensions' => array_merge(
        (require VENDOR_PATH . 'yiisoft/extensions.php'),
        [
            'mailchimp/mailchimp-api' =>
                [
                    'name' => 'mailchimp/mailchimp-api',
                    'version' => '1.0.0',
                    'alias' =>
                        [
                            '@Mailchimp' => '@extensions/mailchimp-api',
                            '@MailchimpOAuth' => '@extensions/mailchimp-api/OAuth2',
                        ]
                ]
        ]
    ),

    'modules' => [
        'gridview' => [
            'class' => '\kartik\grid\Module'
        ]
    ],

    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => '18OWzrgk1kOkX9TEi_Y4jqwu86a-yqhk',
        ],

        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],

        // Multilingual Module
        'i18n' => [
            'translations' => [
                'mail' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/messages'
                ],

                'auth' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/messages'
                ],


                'messages' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/messages'
                ],
                'activityMessages' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/messages',
                    'sourceLanguage' => 'en-US'
                ],

                'alpha' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/messages'
                ],
                'faq' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/messages'
                ],
            ],
        ],

        'user' => [
            'class' => 'app\components\WebUser',
            'identityClass' => 'app\models\UserIdentity',
            'enableAutoLogin' => false,
            'authTimeout' => 5000,
            'loginUrl' => ['site/init']
        ],

        'appLog' => [
            'class' => 'app\components\AppLogger',
            'logType' => 1,
            'logParams' => [
                1 => [
                    'logPath' => LOG_BASE_PATH . 'digitalebox/',
                    'logName' => '-activity.log',
                    'logLevel' => 3, // Take necessary value from apploger class
                    'logSocket' => '',
                    'fileMode' => 0777,
                    'isConsole' => false

                ],
                2 => [
                    'logPath' => LOG_BASE_PATH . 'digitalebox/',
                    'logName' => '-daemon.log',
                    'logLevel' => 3, // Take necessary value from apploger class
                    'logSocket' => '',
                    'fileMode' => 0777,
                    'isConsole' => false
                ]
            ]
        ],
        'authManager' => [
            'class' => 'app\components\RbacAuthManager',
            'defaultRoles' => ['guest'],
        ],

        'errorHandler' => [
            'errorAction' => 'site/error',
        ],

        'mailjetApi' => [
            'class' => 'app\components\MailjetApi',
        ],

        'mailer' => [
            'class' => 'weluse\mailjet\Mailer',
            'apikey' => 'b8f763d0191c81ee46025ac89e064e86',
            'secret' => 'f757366e426814d9a1e85673ef3541be',
        ],

        'Bitly' => [
            'class' => 'app\components\Bitly',
            'access_token' => 'f3b52f710f7abcda26279d82a24bacb792d227e5',
            'client_id' => 'bf9cb4f1ff238bdfc291fc99066f407e45ae15ce',
            'client_secret' => '63be365a9910221ffe023cf6d915a9664cfee5a0',
        ],

         // Twitter
        'twitter' => [
            'class' => 'app\components\TwitterApi',
        ],

        // Linkdin
        'linkedIn' => [
            'class' => 'app\components\LinkedInApi',
        ],


        // This connection initially connected with master database and
        // dynamically change according to database
        'db' => $db,
        // Always connected to master database
        'dbMaster' => [
            'class' => 'yii\db\Connection',
            'emulatePrepare' => true,
            'dsn' => 'mysql:host=217.182.86.46;dbname=DigitaleBoxMaster',
            'username' => 'root',
            'password' => 'Bz5?QtH&ESdr',
            'charset' => 'utf8',
        ],

        // SMS API
        'sms' => [
            'class' => 'wadeshuler\sms\twilio\Sms',

            // Advanced app use '@common/sms', basic use '@app/sms'
            'viewPath' => '@app/sms',     // Optional: defaults to '@app/sms'

            // send all sms to a file by default. You have to set
            // 'useFileTransport' to false and configure the messageConfig['from'],
            // 'sid', and 'token' to send real messages
            'useFileTransport' => false,

            'messageConfig' => [
                'from' => '+33644606440',  // Your Twilio number (full or shortcode)
            ],

            // Find your Account Sid and Auth Token at https://twilio.com/console
            'sid' => 'AC34f13cac8770da156f67466c5dfc2815',
            'token' => '1f1ec973897a1b9507e1b23fd01a7646',

            // Tell Twilio where to POST information about your message.
            // @see https://www.twilio.com/docs/sms/send-messages#monitor-the-status-of-your-message
            //'statusCallback' => 'https://example.com/path/to/callback',      // optional
            'statusCallback' => 'https://vpv.digitalebox.com/index.php/sms-api/sms-event-callback',
        ],

        'toolKit' => [
            'class' => 'app\components\ToolKit',
        ],

        'thresHoldChecker' => [
            'class' => 'app\components\ThresholdChecker',
        ],

        'view' => [
            'class' => 'app\components\View',
            'theme' => [
                'pathMap' => ['@app/views' => '@webroot/themes/bootstrap_spacelab/views'],
                'baseUrl' => '@web/themes/bootstrap_spacelab',
                'basePath' => '@app/web/themes/bootstrap_spacelab',
            ],
        ],

        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
                '<controller:\w+>/<id:\d+>' => '<controller>/view',
                '<controller:\w+>/<action:\w+>/<id:\d+>' => '<controller>/<action>',
                '<controller:\w+>/<action:\w+>' => '<controller>/<action>',
                '<controller:[a-z-]+>/<action:[a-z-]+>/<id:\d+>/<param:[a-z-]+>' => '<controller>/<action>',
                '<controller:[a-z-]+>/<action:[a-z-]+>/<param:[a-z-]+>/<id:\d+>' => '<controller>/<action>',
                'advanced-search/stop-bulk-export/<id:\d+>' => 'advanced-search/stop-bulk-export',
                'advanced-search/stop-bulk-edit/<id:\d+>' => 'advanced-search/stop-bulk-edit',
                'advanced-search/stop-bulk-delete/<id:\d+>' => 'advanced-search/stop-bulk-delete',
            ],
        ],

        'assetManager' => [
            'bundles' => [
                'yii\bootstrap\BootstrapAsset' => [
                    'css' => [],
                ],
            ],
        ],

    ],
    'params' => $params,
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
        // uncomment the following to add your IP if you are not connecting from localhost.
        //'allowedIPs' => ['127.0.0.1', '::1'],
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
        // uncomment the following to add your IP if you are not connecting from localhost.
        //'allowedIPs' => ['127.0.0.1', '::1'],
    ];
    $config['components']['urlManager']['showScriptName'] = true;
}

return $config;
