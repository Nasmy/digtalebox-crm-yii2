<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=217.182.86.46;dbname=DigitaleBoxMaster',
    'username' => 'root',
    'password' => 'Bz5?QtH&ESdr',
    'charset' => 'utf8',
];
