<?php
define('LOG_BASE_PATH', '/var/log/');
define('SYS_TMP_PATH', '/var/www/html/DigitaleBoxMigration/protected/web/uploads');
define('BULK_INSERT_PATH', '/var/www/html/DigitaleBoxMigration/protected/web/erruploads');
define('EXTERNAL_LOG_PATH', '/var/log/digitalebox/');
return [
    'isConsole'=>true,

    'copyRight' => Yii::t('messages', 'Copyright &copy; {date} by DigitaleBox. All Rights Reserved.', array('{date}'=>date('Y'))),

    // Console script path
    'consolePath' => '/var/www/html/DigitaleBoxMigration/protected/web/',

    // Tinymise file upload
    'tinyMiceUpload'=>'/var/www/html/DigitaleBoxMigration/protected/web/images/',

    // Bulk insert path
    'ExcelPath' => '/var/www/html/DigitaleBoxMigration/protected/web/excel/',

    // Absolute URL for application. Used in console apps to create dynamic URLs
    'absUrl' => "http://{domain}/index.php",

    // Absolute path to temp directory within web root
    'webTempAbsPath' => 'temp/',

    // Relative path to temp directory within web root
    'webTempRelPath' => 'temp/',

    // Maximum upload size of candidate photo
    'maxImgSize' => 2,

    // Client profile thumbnail name
    'clientProfThumbName' => 'clientProfThumb',

    // Default page size
    'pageSize' => 10,

    // Paypal sandbox mode (true/false)
    'paypalSandbox' => true,

    // Default Domain
    'liveDomain' => 'vpv.digitalebox.com',

    // OSM params
    'openStreetMap' => [
        'consumerKey' => 'hYLxGhvTTewFBm6vep18NqCQh90rBpb6',
        'consumerSecret' => 'rNFcW8rq6dhP4fOF'
    ],

    // Default longitude and latitude to point map when long lat not available
    'defLongLat' => '45.227309, 14.868457', // Bellow Slovenia

    // Twitter params
    'twitter' => [
        'consumerKey' => 'IHSaisHNQ3lpFBl8WYcpk68uR',
        'consumerSecret' => '7AM4kBmHKRALNrFr0yJlRJwkViiq7z2E46FMlAL9b2hY4BhDpi',
        'callback_url' => "https://vpv.digitalebox.com/index.php/signup/callback/network/%s/?domain=%s",
        'redirectUri' => "https://%s/index.php/signup/callback/network/%s/?oauth_token=%s&&oauth_verifier=%s",
        'oauthToken' => '2427209282-TEsz34fqR04Iz1Qwv6qGvsxBdFtVwRIUqduytqe',
        'oauthTokenSecret' => 'HS7VoPL9iFz5OPIpgAyTsVW3sTmukctDoETMqC6LvaWJn',
        'maxFollowBack' => '20',  	// Maximum number of daily Twitter followback
        'maxFollowOther' => '20', 	// Maximum number of daily following of other account
        'maxUnfollow' => '20', 		// Maximum number of daily unfollowings
        'unfolDays' => '4' 			// Number of day to keep following before unfollow
    ],

    // Facebook parameters
    'facebook' => [
        'loginScope' => [
            'public_profile',
            'email',
            'user_friends',
            // Need approval
            'user_location',
            'manage_pages',
            'publish_pages',
            'publish_actions',
        ],
        'redirectUri' => "http://%s/index.php/Signup/Callback/network/%s",
    ],

    'linkedIn' => [
        'apiKey' => '77z9lvhwf2ec10',
        'apiSecret' => 'zHbtDXGvwgxZbg7j',
        'callbackUrl' => 'https://vpv.digitalebox.com/index.php/auth-call-back/linked-in-callback',
        //http://staging.moncenis.com/index.php/authCallBack/LinkedInCallback
        'maxPagePostBackDays'=>10, // Maximum number of days to fetch Linked page posts from current date
        'tokenRefreshDays' => 50
    ],

    // Google API https://code.google.com/apis/console/?noredirect&pli=1#project:618443992883:access
    'google' => [
        // Project APIs
        'apiKey'=>'AIzaSyCUDSJ2GBE1DHupbAZT4u8gZqclkIhmb0M',

        // Project Digitalebox-Staging
        'clientId'=>'47312430286-of3dodvbj45q592gv4ihdcs7h1ffb90r.apps.googleusercontent.com',
        'clientSecret'=>'g64ZJyKaSd-e4baueVdtp_hm',
        'redirectUri'=>'https://vpv.digitalebox.com/index.php/auth-call-back/google-callback',

        // Request URIs
        'uriGetContacts'=>'https://www.google.com/m8/feeds/contacts/{contact}/full?v=3.0',
    ],

    'googlePlus' => [
        'apiKey' => '99228151187-5ik3d6a46ioc8nn9u7i341k4di36fpbf.apps.googleusercontent.com',
        'apiSecret' => 'e66XlKTeGDMO_1aZYuftqWCu',
        'redirectUri'=>'https://peeem.digitalebox.fr/index.php/auth-call-back/google-plus-callback',
    ],

    // Yahoo API http://developer.apps.yahoo.com/projects/tVDvRc5a
    'yahoo' => [
        'consumerKey' => 'dj0yJmk9N0FMZmw4VlMyTUZpJmQ9WVdrOWNGVndSemM0TldjbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1hMA--',
        'consumerSecret' => '41773bea72562b04ed2f65052eb16cd0260bfc68',
        'callbackUrl' => 'https://vpv.digitalebox.com/index.php/auth-call-back/yahoo-call-back',
        'oauthInitUrl' => 'http://peem.digitalebox.com/index.php/authCallBack/yahoo-oath-init',
    ],


    'stripe' => array (
        'secretKey' => 'sk_test_9uQec8BCZUTFM2UlznJuhnJV',
        'publishableKey' => 'pk_test_tedeA4LaVEEImn0vzC9DsAHM',
        'currencyCode' => 'EUR',
        'cardBrands' => 'card-brands.png',
    ),

    'instagram' => [
        'clientId' => 'a5c392bd02074e80b8743743b7400f69',
        'clientSecret' => 'ad10f9514ae74ae2a84d974d474cda08',
        'callbackUrl' => 'http://peeem.digitalebox.fr/index.php/AuthCallBack/InstagramCallBack'
    ],

    'mailchimp' => [
        'clientId' => '968420432554',
        'clientSecret' => 'f49dc0ad0ac03c5116122d0f4a2dfbd2',
        'callbackUri' => 'https://auth.moncenis.com/index.php/auth-call-back/mailchimp-call-back',
    ],

    // SMTP connection settings
    'smtp' => array(
        // Mailjet account
        'host' => 'in.mailjet.com:25',
        'username' => 'b8f763d0191c81ee46025ac89e064e86',
        'password' => 'f757366e426814d9a1e85673ef3541be',
        'senderEmail' => 'system@digitalebox.fr', // For all the emails this will send as sender parameter
        'defaultClientEmail' => 'contact@digitalebox.fr',
        'senderLabel' => 'Digitalebox',
        'eventCallbackUrl' => 'https://vpv.digitalebox.com/index.php/email-api/email-event-callback',
        'logsEmail' => 'log@digitalebox.fr',
    ),


    // SMS API
    'smsApi' => [
        'sid' => 'AC34f13cac8770da156f67466c5dfc2815',
        'token' => '1f1ec973897a1b9507e1b23fd01a7646',
        'defSenderId' => '+33644606440', //A Twilio phone number you purchased at twilio.com/console
        'messagingServiceSid' => 'MG50fa7e0b84e37bccd22cbd09a1a68c64',
    ],

    'blyApi' => [
        'genericAccessToken' => '418f3d612a8be99af33d272e622acf438563eca2',
        'clientId' => '6feb8a87a212e2ea5ebf7e0b4579066a13a82d2b',
        'clientSecret' => '66fe7c0328efbad223ea2b040d27497f5925f501',
        'callbackUrl' => 'https://vpv.digitalebox.com/index.php/auth-call-back/bitly-callback',
    ],

    'changeApi' => [
        'apiKey' => '32cf9810f982f95613cec5cce3154dc83966f2a89111661e6355938ad70b20f6',
        'secret' => '6acc5384782f8449e2775c3abf7688ec89cfa1ac76c710f2a745ad5c323e5bc9',
        'pageSize'=> 100,
        'host'=> 'https://api.change.org',
    ],

    'fileUpload' => [
        'people' => [
            'path'=> SYS_TMP_PATH . '/',
            'name'=> "%s_bulk_people" . date('_Y-m-d_') . "%s",
            'delimiter' => ',',
        ],
        'status' => [
            'path' => SYS_TMP_PATH . '/',
            'name' => 'bulk_status_' . date('Y-m-d-H-i-s') . '.csv',
            'address' => 'address_status_' . date('Y-m-d-H-i-s') . '.csv',
        ],
        'export' => [
            'path' => SYS_TMP_PATH . '/',
            'name' => 'bulk_export_' . date('Y-m-d-H-i-s') . '.csv',
            'address' => 'address_export_' . date('Y-m-d-H-i-s') . '.csv',
        ],

        'error' =>[
            'path' => BULK_INSERT_PATH . '/',
            'name' => 'bulk_status_' . date('Y-m-d-H-i-s') . '.csv',
        ],

    ],

    // Languages for localization
    'lang' => [
        'en-US' => array(
            'identifier' => 'en-US',
            'flagName' => 'en-US.png',
            'name' => 'English',
        ),
        'fr-FR' => array(
            'identifier' => 'fr-FR',
            'flagName' => 'fr-FR.png',
            'name' => 'Français',
        ),
        'pt' => array(
            'identifier' => 'pt-PT',
            'flagName' => 'pt.png',
            'name' => 'Português',
        ),
        'it' => array(
            'identifier' => 'it-IT',
            'flagName' => 'it.png',
            'name' => 'Italiano',
        ),
        'ru' => array(
            'identifier' => 'ru-RU',
            'flagName' => 'ru.png',
            'name' => 'Russian',
        ),
    ],

    // Currency types to configure on system
    'currencyTypes' => [
        'USD' => ['name' => 'U.S. Dollar', 'symbol'=> 'US$'],
        'EUR' => ['name' => 'Euro', 'symbol'=> '�'],
        'CAD' => ['name' => 'Canadian Dollar', 'symbol'=> 'C$'],
    ],

    // Domain of main application
    'masterDomain' => '217.182.86.46',


    // Absolute path to resource folder
    //D:\Customer\DigitalBox\Project\UI\DigitaleBox\resourcesz
    'resourcePath'=>'/var/www/html/DigitaleBoxMigration/protected/web/resources/',

    // Ipinfo is a service to obtain geo details by IP. It allows 1000 free API requests per day
    // http://ipinfo.io
    'ipInfoUrl' => 'http://ipinfo.io/',

    // Default longitude and latitude to point map when long lat not available
    //'defLongLat' => '48.856614,2.3522', // Paris
    // 'defLongLat' => '45.227309, 14.868457', // Bellow Slovenia

    // Number of days to keep Email Events on EmailEventTracker table of Master database
    'emailEventsDelExpire' => 10,

    // For these actions system check for user`s package limitations
    'thresholdActions' => [
        'People.Create',
        'People.BulkInsert',
        'AdvancedBulkInsert.Create'
    ],

    // French special characters to be detected on SMS message
    'smsSpecialChars' => '�����',

    // Main application login URL
    'salesAppUrl' => 'https://digitalebox.fr/index.php',

    'themes' => [
        1 => ['cssFile'=>'style-sky-blue.css', 'thumbnail'=>'skyblue-th.jpg', 'lgImage'=>'skyBlue.png', 'color'=>'#2FA4E7', 'class'=>'theme-blue', 'preview'=>'theme-blue-preview.jpg', 'configTheme'=>'blue', 'themeName'=>'Blue'],
        2 => ['cssFile'=>'style-green-tea.css', 'thumbnail'=>'green-tea-th.jpg', 'lgImage'=>'greenTea.png', 'color'=>'#95AB63','class'=>'theme-green', 'preview'=>'theme-green-preview.jpg', 'configTheme'=>'green', 'themeName'=>'Green'],
        3 => ['cssFile'=>'style-sunset.css', 'thumbnail'=>'sunset-th.jpg', 'lgImage'=>'sunset.png', 'color'=>'#C33A1A', 'class'=>'theme-red', 'preview'=>'theme-red-preview.jpg', 'configTheme'=>'red', 'themeName'=>'Red'],
        4 => ['cssFile'=>'style-indego.css', 'thumbnail'=>'indego-th.jpg', 'lgImage'=>'indego.png', 'color'=>'#734061', 'class'=>'theme-purple', 'preview'=>'theme-purple-preview.jpg', 'configTheme'=>'purple', 'themeName'=>'Purple']
    ],

    'emailDomain' => [
        'url1' => 'https://template-revamp.digitalebox.com',
        'url2' => 'https://template.influencemaker.fr'
    ],

    'campaign' => [
        'campaignEmail' => 'campaign@digitalebox.fr',
        'limit' => 5,
    ],

    'privacyUrl' => 'https://digitalebox.fr/index.php/site/privacy',
    'bsDependencyEnabled' => false
];
